package controller;

import model.Departamento;
import model.EmpresaDao;
import model.Funcionario;
import model.Usuario;

public class Controle {
    
    EmpresaDao dao;
    Usuario usu;
    Departamento dep;
    Funcionario fun;
    String flag;
    String idDep, nomeDep, telefoneDep,
           emailFun, senhaUsu,
           nomeFun, telefoneFun, cargoFun;
    Double salarioFun;
        
    
    
    
           
    
    
}
