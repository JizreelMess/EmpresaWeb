package model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class EmpresaDao {
    
    private EntityManagerFactory factory;
    private EntityManager manager;
    
    public void conectar(){
    factory = Persistence.createEntityManagerFactory("ProjetoWebPU");
    manager = factory.createEntityManager();
    }
    
    public void desconectar(){
    factory.close();
    manager.close();  
    }   
    
    public Usuario validarLogin(String u, String s){
        conectar();
        try
        {
        TypedQuery<Usuario> query = manager.createNamedQuery("Usuario.findByEmailSenha", Usuario.class);
        query.setParameter("emailFun", u);
        query.setParameter("senhaUsu", s);
        return query.getSingleResult();
        }
        catch(NoResultException x)
        {
         return null;
        }
}
    
    
    
    
    
}